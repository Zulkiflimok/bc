# -*- coding: utf-8 -*-
#BROADCASTBOTS BY: ZULKIFLI MOKOAGOW
#      ZULKIFLI MOKOAGOW
# line id: line.me/ti/p/~linux.1
from important import *
import youtube_dl
import requests
import humanize
import html5lib
from gtts import gTTS
from bs4 import BeautifulSoup
import requests, json
import urllib, urllib3, urllib.parse
from thrift import transport, protocol, server
from thrift.Thrift import *
from thrift.TMultiplexedProcessor import *
from thrift.TSerialization import *
from thrift.TRecursive import *
from thrift.protocol import TCompactProtocol
from thrift.transport import THttpClient
from gtts import gTTS
from googletrans import Translator
parser = argparse.ArgumentParser(description='Selfbot By BAI')
parser.add_argument('-t', '--token', type=str, metavar='', required=False, help='Token | Example : Exxxx')
parser.add_argument('-e', '--email', type=str, default='', metavar='', required=False, help='Email Address | Example : example@xxx.xx')
parser.add_argument('-p', '--password', type=str, default='', metavar='', required=False, help='Password | Example : xxxx')
parser.add_argument('-a', '--apptype', type=str, default='', metavar='', required=False, choices=list(ApplicationType._NAMES_TO_VALUES), help='Application Type | Example : CHROMEOS')
parser.add_argument('-s', '--systemname', type=str, default='', metavar='', required=False, help='System Name | Example : Chrome_OS')
parser.add_argument('-c', '--channelid', type=str, default='', metavar='', required=False, help='Channel ID | Example : 1341209950')
parser.add_argument('-T', '--traceback', type=str2bool, nargs='?', default=False, metavar='', required=False, const=True, choices=[True, False], help='Using Traceback | Use : True/False')
parser.add_argument('-S', '--showqr', type=str2bool, nargs='?', default=False, metavar='', required=False, const=True, choices=[True, False], help='Show QR | Use : True/False')
args = parser.parse_args()
listAppType = ['DESKTOPWIN', 'DESKTOPMAC', 'IOSIPAD', 'CHROMEOS','ANDROIDLITE']
line = LINE("imel@gmail.com","paswort") #ganti ime kalian
#=======================================================================================================================
myMid = line.profile.mid
mySettings = line.getSettings()
myMID = line.getProfile().mid
programStart = time.time()
oepoll = OEPoll(line)
creator = ["ganti mid admin"] #ganti dengan mid kamu
admin = ["settings"]
tmp_text = []
lurking = {}
settings = livejson.File('setting.json', True, False, 4)
silent = livejson.File('silent.json', True, False, 4)
tagmeOpen = codecs.open("tag.json","r","utf-8")

tagme = json.load(tagmeOpen)
lastseen = ({
    "find": {},
    "username": {}
})
liffV1 = {
    "arLiff": True
}
bool_dict = {
    True: ['Yes', 'Active', 'Success', 'Open', 'On'],
    False: ['No', 'Not Active', 'Failed', 'Close', 'Off']
}
profile = line.getContact(myMid)
settings['myProfile']['displayName'] = profile.displayName
settings['myProfile']['statusMessage'] = profile.statusMessage
settings['myProfile']['pictureStatus'] = profile.pictureStatus
coverId = line.profileDetail['result']['objectId']
settings['myProfile']['coverId'] = coverId
if not settings:
    print ('##----- LOAD DEFAULT JSON -----##')
    try:
        default_settings = line.server.getJson('https://17hosting.id/default.json')
        settings.update(default_settings)
        print ('##----- LOAD DEFAULT JSON (Success) -----##')
    except Exception:
        print ('##----- LOAD DEFAULT JSON (Failed) -----##')
def restartProgram():
    print ('##----- PROGRAM RESTARTED -----##')
    python = sys.executable
    os.execl(python, python, *sys.argv)
def logError(error, write=True):
    errid = str(random.randint(100, 999))
    filee = open('tmp/errors/%s.txt'%errid, 'w') if write else None
    if args.traceback: traceback.print_tb(error.__traceback__)
    if write:
        traceback.print_tb(error.__traceback__, file=filee)
        filee.close()
        with open('errorLog.txt', 'a') as e:
            e.write('\n%s : %s'%(errid, str(error)))
    print ('++ Error : {error}'.format(error=error))
def command(text):
    pesan = text.lower()
    if settings['setKey']['status']:
        if pesan.startswith(settings['setKey']['key']):
            cmd = pesan.replace(settings['setKey']['key'],'')
        else:
            cmd = 'Undefined command'
    else:
        cmd = text.lower()
    return cmd
def genImageB64(path):
    with open(path, 'rb') as img_file:
        encode_str = img_file.read()
        b64img = base64.b64encode(encode_str)
        return b64img.decode('utf-8')
def allowLiff3(): #LIFF TROJAN
    url = 'https://access.line.me/dialog/api/permissions'
    data = {
        'on': [
            'P',
            'CM'
        ],
        'off': []
    }
    headers = {
        'X-Line-Access': line.authToken,
        'X-Line-Application': line.server.APP_NAME,
        'X-Line-ChannelId': '1638870522',
        'Content-Type': 'application/json'
    }
    requests.post(url, json=data, headers=headers)
def allowLiff2(): #LIFF EATER
    url = 'https://access.line.me/dialog/api/permissions'
    data = {
        'on': [
            'P',
            'CM'
        ],
        'off': []
    }
    headers = {
        'X-Line-Access': line.authToken,
        'X-Line-Application': line.server.APP_NAME,
        'X-Line-ChannelId': '1586794970',
        'Content-Type': 'application/json'
    }
    requests.post(url, json=data, headers=headers)         
def allowLiff(): #LIFF AR
    url = 'https://access.line.me/dialog/api/permissions'
    data = {
        'on': [
            'P',
            'CM'
        ],
        'off': []
    }
    headers = {
        'X-Line-Access': line.authToken,
        'X-Line-Application': line.server.APP_NAME,
        'X-Line-ChannelId': '1602687308',
        'Content-Type': 'application/json'
    }
    requests.post(url, json=data, headers=headers)
def sendTemplate(to, data):
    allowLiff()
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    if liffV1["arLiff"]: view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    else: view = LiffViewRequest('1586794970-VKzbNLP7', xyzz)
    token = line.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
    
def sendTemplate3(to, data):
    allowLiff3()
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1638870522-PnjreV13', xyzz)
    token = line.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
def sendTemplate2(to, data):
    allowLiff2()
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1586794970-VKzbNLP7', xyzz)
    token = line.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
def genUrlB64(url):
    return base64.b64encode(url.encode('utf-8')).decode('utf-8')
def removeCmd(text, key=''):
    if key == '':
        setKey = '' if not settings['setKey']['status'] else settings['setKey']['key']
    else:
        setKey = key
    text_ = text[len(setKey):]
    sep = text_.split(' ')
    return text_[len(sep[0] + ' '):]
def multiCommand(cmd, list_cmd=[]):
    if True in [cmd.startswith(c) for c in list_cmd]:
        return True
    else:
        return False
def replaceAll(text, dic):
    try:
        rep_this = dic.items()
    except:
        rep_this = dic.iteritems()
    for i, j in rep_this:
        text = text.replace(i, j)
    return text
def parsingRes(res):
    result = ''
    textt = res.split('\n')
    for text in textt:
        if True not in [text.startswith(s) for s in ['╭', '║✈︎', '│', '╰']]:
            result += '\n│ ' + text
        else:
            if text == textt[0]:
                result += text
            else:
                result += '\n' + text
    return result
def mentionMembers(to, mids=[]):
    if myMid in mids: mids.remove(myMid)
    parsed_len = len(mids)//20+1
    result = 'Mention Members \n'
    mention = '@zulkifli\n'
    no = 0
    for point in range(parsed_len):
        mentionees = []
        for mid in mids[point*20:(point+1)*20]:
            no += 1
            result += '| %i. %s' % (no, mention)
            slen = len(result) - 12
            elen = len(result) + 3
            mentionees.append({'S': str(slen), 'E': str(elen - 4), 'M': mid})
            if mid == mids[-1]:
                result += '\n              \n'
        if result:
            if result.endswith('\n'): result = result[:-1]
            line.sendMessage(to, result, {'MENTION': json.dumps({'MENTIONEES': mentionees})}, 0)
        result = ''
def mentionMembers2(gid, mids=[]):
    if myMid in mids: mids.remove(myMid)
    parsed_len = len(mids)//20+1
    G = line.getGroup(gid)
    result = 'REMOTE MENTION\n'
    mention = '@zulkifli\n'
    no = 0
    for point in range(parsed_len):
        mentionees = []
        for mid in mids[point*20:(point+1)*20]:
            no += 1
            result += ' %i. %s' % (no, mention)
            slen = len(result) - 12
            elen = len(result) + 3
            mentionees.append({'S': str(slen), 'E': str(elen - 4), 'M': mid})
            if mid == mids[-1]:
                result += '           /n'
        if result:
            if result.endswith('\n'): result = result[:-1]
            line.sendMessage(gid, result, {'MENTION': json.dumps({'MENTIONEES': mentionees})}, 0)
        result = ''            
def sendMention(to, text="", mids=[]):
    arrData = ""
    arr = []
    mention = "@zulkifli "
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 15
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    line.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
def debug():
    get_profile_time_start = time.time()
    get_profile = line.getProfile()
    get_profile_time = time.time() - get_profile_time_start
    get_profile_took = time.time() - get_profile_time_start
    return "Rec Moments : %.5f\n  Speed : %.3fms" % (get_profile_took,get_profile_time)
def restoreProfile():
    profile = line.getProfile()
    profile.displayName = settings['myProfile']['displayName']
    profile.statusMessage = settings['myProfile']['statusMessage']
    line.updateProfile(profile)
    if settings['myProfile']['pictureStatus']:
        pict = line.downloadFileURL('http://dl.profile.line-cdn.net/' + settings['myProfile']['pictureStatus'])
        line.updateProfilePicture(pict)
    coverId = settings['myProfile']['coverId']
    line.updateProfileCoverById(coverId)
def executeCmd(msg, text, txt, cmd, msg_id, receiver, sender, to, setKey):
    if cmd == 'off':
      if msg._from in creator or msg._from in settings["admin"]:
        if to in silent['silent']:
            line.sendReplyMessage(msg.id, to, 'HMMMM! :)\nPlease Usage Commands "off" ')
        else:
            silent['silent'].append(to)
            line.sendReplyMessage(msg.id, to, 'BOT OFF!')
    elif cmd == 'on':
      if msg._from in creator or msg._from in settings["admin"]:
        if to not in silent['silent']:
            line.sendReplyMessage(msg.id, to, "HMMMM! :)")
        else:
            silent['silent'].remove(to)
            line.sendReplyMessage(msg.id, to, 'BOT ON!')
    if to in silent['silent']:
        return
    if cmd == '/logout':
      if msg._from in creator or msg._from in settings["admin"]:
        line.sendMessage(to, 'Selfbot will logged out')
        sys.exit('##----- PROGRAM STOPPED -----##')
    elif cmd == 'logoutdevicee':
      if msg._from in creator or msg._from in settings["admin"]:
        line.logout()
        sys.exit('##----- CLIENT LOGOUT -----##')
    elif cmd == '/restart':
      if msg._from in creator or msg._from in settings["admin"]:
        line.sendMessage(to, 'DONE RESTART♪')
        settings['restartPoint'] = to
        restartProgram()
#================Menu Help================
    elif cmd.startswith('help2'):
      if msg._from in creator:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        cond = textt.split(' ')
        res = '    〘 𝗛𝗘𝗟𝗣 𝗖𝗥𝗘𝗔𝗧𝗢𝗥 〙    '
        res +='\n'
        res += '\n • ʀɴᴀᴍᴇ'
        res += '\n • ᴜᴘʀɴᴀᴍᴇ: < ᴛᴇxᴛ > '
        res += '\n • ᴄʜᴀɴɢᴇɴᴀᴍᴇ: < ᴛᴇxᴛ >'        
        res += '\n • ʙᴄᴀᴅᴅ <@>'
        res += '\n • ʙᴄᴅᴇʟ <@>'
        res += '\n • ʙᴄʟɪsᴛ'
        res += '\n • ʙᴄs: <ᴛᴇxᴛ>'
        res += '\n • sᴘᴇᴇᴅ'
        res += '\n • ᴍᴇ'       
        res += '\n • ɪɴғᴏᴍᴇᴍ'
        res += '\n • ʙᴏᴛ'
        res += '\n • ʀᴇᴄʜᴀᴛ'
        res += '\n • ʙʏᴇ/ʟᴇᴀᴠᴇ'
        res += '\n • ɪɴᴠɪᴛᴇᴍᴇ'
        res+=  '\n • ɢʀᴏᴜᴘʟɪsᴛ'
        res += '\n • ғʀɪᴇɴᴅʟɪsᴛ'
        res += '\n • ʀᴜɴᴛɪᴍᴇ'
        res += '\n • ᴠᴘsɪɴғᴏ'
        if cmd == 'help2':
            data = {
                                           "type": "text",
                                           "text": "{}".format(str(res)),
                                           "sentBy": {
                                           "label": "TEAM TERMUX™".format(line.getContact(myMid).displayName),
                                           "iconUrl": "https://i.ibb.co/QNFxN8N/1652366614290.jpg".format(line.getContact(myMid).pictureStatus),
                                           "linkUrl": "line://nv/profilePopup/mid=u6459106c8251205f79c2f037cd99b6a4",
                                         }
                                     }
            sendTemplate(to, data)
#=======================================
    elif cmd == 'help':
      if msg._from in creator or msg._from in settings["admin"]:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        cond = textt.split(' ')
        res = '    〘 𝗛𝗘𝗟𝗣 𝗕𝗥𝗢𝗔𝗗𝗖𝗔𝗦𝗧 〙    '
        res +='\n'
        res += '\n • ʀɴᴀᴍᴇ'
        res += '\n • ʙᴄs: <ᴛᴇxᴛ>'
        res += '\n • ᴍᴇ'       
        res += '\n • ʙᴏᴛ'
        res += '\n • ʜᴇʟᴘ𝟸 <ғᴏʀ ᴄʀᴇᴀᴛᴏʀ>' 
        if cmd == 'help':
            data = {
                                           "type": "text",
                                           "text": "{}".format(str(res)),
                                           "sentBy": {
                                           "label": "TEAM TERMUX™".format(line.getContact(myMid).displayName),
                                           "iconUrl": "https://i.ibb.co/QNFxN8N/1652366614290.jpg".format(line.getContact(myMid).pictureStatus),
                                           "linkUrl": "line://nv/profilePopup/mid=u6459106c8251205f79c2f037cd99b6a4",
                                         }
                                     }
            sendTemplate(to, data)            
#================BATAS================
    elif cmd == ' speed' or cmd == 'sp':
      if msg._from in creator or msg._from in settings["admin"]:
            debugs = debug()
            data = {
                                           "type": "text",
                                           "text": "{}".format(str(debugs)),
                                           "sentBy": {
                                           "label": "TEAM TERMUX™".format(line.getContact(myMid).displayName),
                                           "iconUrl": "https://i.ibb.co/QNFxN8N/1652366614290.jpg".format(line.getContact(myMid).pictureStatus),
                                           "linkUrl": "line://nv/profilePopup/mid=u6459106c8251205f79c2f037cd99b6a4",
                                         }
                                     }
            sendTemplate(to, data)
    elif cmd == "me" or text.lower() == ' me':
      if settings["selfbot"] == True:
        if msg._from in creator or msg._from in settings["admin"]:
           msg.contentType = 13
           msg.contentMetadata = {'mid': msg._from}
           line.sendReplyMessage(msg.id, to, None, contentMetadata={'mid': msg._from}, contentType=13)     
    elif cmd == 'bot':
      if msg._from in creator or msg._from in settings["admin"]:
        line.sendMessageMusic(to, title=line.getContact(myMid).displayName, subText=str(line.getContact(myMid).statusMessage), url='line://nv/profilePopup/mid=u6459106c8251205f79c2f037cd99b6a4', iconurl="http://dl.profile.line-cdn.net/{}".format(line.getContact(myMid).pictureStatus), contentMetadata={})
    elif cmd == 'runtime':
      if msg._from in creator or msg._from in settings["admin"]:
        runtime = time.time() - programStart
        line.sendMessage(to, ' Waktu Hidup ' + format_timespan(runtime))
    elif cmd == '':
      if msg._from in creator or msg._from in settings["admin"]:
        line.sendMessage(to,'BROADCASTBOTS WAS HERE ☺')
    elif cmd == "creator":
      if settings["selfbot"] == True:
        line.sendContact(to, "u6459106c8251205f79c2f037cd99b6a4")        
    elif cmd == 'rechat':
      if msg._from in creator or msg._from in settings["admin"]:
        line.sendMessage(to,'wait....')    
    elif cmd == 'join':
      if msg._from in creator or msg._from in settings["admin"]:
        line.sendMessage(to,'accept all')            
    elif cmd == 'ceklimit' or cmd == 'cek':
      if msg._from in creator or msg._from in settings["admin"]:
        try:line.inviteIntoGroup(to, ["u6cde52ae3728a79d00dd0d91ceea1bd7"]);has = "OK"
        except:has = "NOT"
        try:line.kickoutFromGroup(to, ["u6cde52ae3728a79d00dd0d91ceea1bd7"]);has1 = "OK"
        except:has1 = "NOT"
        try:line.cancelGroupInvitation(to, ["u6cde52ae3728a79d00dd0d91ceea1bd7"]);has2 = "OK"
        except:has2 = "NOT"
        idbob = line.getProfile().userid
        try:line.findContactsByUserid(idbob);has3 = "OK"
        except:has3 = "NOT"
        if has == "OK":sil = "✔"
        else:sil = "✖"
        if has2 == "OK":sil2 = "✔"
        else:sil2 = "✖"
        if has3 == "OK":sil3 = "✔"
        else:sil3 = "✖"
        ret_ = "--- 𝐒𝐭𝐚𝐭𝐮𝐬 𝐋𝐢𝐦𝐢𝐭 ---"
        ret_ += "\n "
        ret_ += "\n Invite: {}".format(sil)
        ret_ += "\n Cancel: {}".format(sil2)
        ret_ += "\n Add: {}".format(sil3)
        data = {
                                           "type": "text",
                                           "text": "{}".format(str(ret_)),
                                           "sentBy": {
                                           "label": "TEAM TERMUX™".format(line.getContact(myMid).displayName),
                                           "iconUrl": "https://i.ibb.co/QNFxN8N/1652366614290.jpg".format(line.getContact(myMid).pictureStatus),
                                           "linkUrl": "line://nv/profilePopup/mid=u6459106c8251205f79c2f037cd99b6a4",
                                         }
                                     }
        sendTemplate(to, data)
    elif cmd == "bye" or cmd == 'leave':
      if msg._from in creator or msg._from in settings["admin"]:
        data = {
                                           "type": "text",
                                           "text": "see you all 👋",
                                           "sentBy": {
                                           "label": "TEAM TERMUX™".format(line.getContact(myMid).displayName),
                                           "iconUrl": "https://i.ibb.co/QNFxN8N/1652366614290.jpg".format(line.getContact(myMid).pictureStatus),
                                           "linkUrl": "line://nv/profilePopup/mid=u6459106c8251205f79c2f037cd99b6a4",
                                         }
                                     }
        sendTemplate(to, data)
        G = line.getGroup(to)
        line.leaveGroup(to)
#================FOR USE VPS (VIRTUAL PRIVAT SERVER)================
    elif cmd.startswith("#exec"):
       if msg._from in creator or msg._from in settings["admin"]:
           try:
               sep = text.split("\n")
               txt = text.replace(sep[0] + "\n","")
               exec(txt)
           except:
               pass
    if cmd == "vpsinfo":
       if msg._from in creator or msg._from in settings["admin"]:
            am = subprocess.getoutput('cat /proc/meminfo')
            core = subprocess.getoutput('grep -c ^processor /proc/cpuinfo ')
            for anu in am.splitlines():
                if 'MemTotal:' in anu:
                    mem = anu.split('MemTotal:')[1].replace(' ','')
                if 'MemFree:' in anu:
                    fr = anu.split('MemFree:')[1].replace(' ','')
            res = '--- 𝐕𝐏𝐒 𝐈𝐍𝐅𝐎 ---'
            res += "\n Cpu Core : {}".format(core)
            res += "\n Total Memory: {}".format(mem)
            res += "\n Free Memory: {}".format(fr)
            data = {
                                           "type": "text",
                                           "text": "{}".format(str(res)),
                                           "sentBy": {
                                           "label": "TEAM TERMUX™".format(line.getContact(myMid).displayName),
                                           "iconUrl": "https://i.ibb.co/QNFxN8N/1652366614290.jpg".format(line.getContact(myMid).pictureStatus),
                                           "linkUrl": "line://nv/profilePopup/mid=u6459106c8251205f79c2f037cd99b6a4",
                                         }
                                     }
            sendTemplate(to, data)
    elif cmd == "clearcache" or cmd == "clear":
      if msg._from in creator or msg._from in settings["admin"]:
            a = os.popen('echo 1 | sudo tee /proc/sys/vm/drop_caches\necho 2 | sudo tee /proc/sys/vm/drop_caches\necho 3 | sudo tee /proc/sys/vm/drop_caches\n').read()
            b = os.popen('cd / && cd tmp && rm *.bin').read()
            res = "Success clear cache VPS"
            data = {
                                           "type": "text",
                                           "text": "{}".format(str(res)),
                                           "sentBy": {
                                           "label": "TEAM TERMUX™".format(line.getContact(myMid).displayName),
                                           "iconUrl": "https://i.ibb.co/QNFxN8N/1652366614290.jpg".format(line.getContact(myMid).pictureStatus),
                                           "linkUrl": "line://nv/profilePopup/mid=u6459106c8251205f79c2f037cd99b6a4",
                                         }
                                     }
            sendTemplate(to, data)           
#================Blacklist & Whitelist================
    elif cmd.startswith("bcadd "):
      if msg._from in creator:
            key = eval(msg.contentMetadata["MENTION"])
            key["MENTIONEES"][0]["M"]
            targets = []
            for x in key["MENTIONEES"]:
                targets.append(x["M"])
            for target in targets:
                try:
                    settings["admin"].append(target)
                    res = "sᴜᴄᴄᴇss ᴀᴅᴅ ᴛᴏ ʙʀᴏᴀᴅᴄᴀsᴛ"
                    data = {
                                                   "type": "text",
                                                   "text": "{}".format(str(res)),
                                                   "sentBy": {
                                                   "label": "TEAM TERMUX™".format(line.getContact(myMid).displayName),
                                                   "iconUrl": "https://i.ibb.co/QNFxN8N/1652366614290.jpg".format(line.getContact(myMid).pictureStatus),
                                                   "linkUrl": "line://nv/profilePopup/mid=u6459106c8251205f79c2f037cd99b6a4",
                                                 }
                                             }
                    sendTemplate(to, data)            
                except:
                    pass
    elif cmd.startswith("bcdel "):
      if msg._from in creator:
            key = eval(msg.contentMetadata["MENTION"])
            key["MENTIONEES"][0]["M"]
            targets = []
            for x in key["MENTIONEES"]:
                targets.append(x["M"])
            for target in targets:
                try:
                    settings["admin"].remove(target)
                    res = "sᴜᴄᴄᴇss ᴅᴇʟ ᴛᴏ ʙʀᴏᴀᴅᴄᴀsᴛ"
                    data = {
                                                   "type": "text",
                                                   "text": "{}".format(str(res)),
                                                   "sentBy": {
                                                   "label": "TEAM TERMUX™".format(line.getContact(myMid).displayName),
                                                   "iconUrl": "https://i.ibb.co/QNFxN8N/1652366614290.jpg".format(line.getContact(myMid).pictureStatus),
                                                   "linkUrl": "line://nv/profilePopup/mid=u6459106c8251205f79c2f037cd99b6a4",
                                                 }
                                             }
                    sendTemplate(to, data)            
                except:
                    pass
    elif cmd == 'bclist':
      if msg._from in creator:
                        if len(settings["admin"]) > 0:
                            h = [a for a in settings["admin"]]
                            k = len(h)//20
                            for aa in range(k+1):
                                if aa == 0:dd = '※ᴀᴄᴄᴇss ʙʀᴏᴀᴅᴄᴀsᴛ ᴜsᴇʀ※\n'"";no=aa
                                else:dd = '';no=aa*20
                                msgas = dd
                                for a in h[aa*20:(aa+1)*20]:
                                    no+=1
                                    if no == len(h):msgas+='{} @!'.format("»")
                                    else:msgas += '{} @!\n'.format("»")
                                sendMention(to, msgas, h[aa*20:(aa+1)*20])
                        else:
                            line.sendReplyMessage(msg.id,to,"Doesn't Have broadcast User ")
    elif cmd.startswith("clearbc"):
      if msg._from in creator:
                        if len(settings["admin"]) > 0:
                            line.sendReplyMessage(msg.id, to, " {} Success Cleared Broadcast User ".format(len(settings["admin"])))
                            settings["admin"].clear()
                        else:
                            line.sendReplyMessage(msg.id,to," Doesn't Have Broadcast User ")
#================BATAS================
    elif cmd.startswith("inviteme "):
      if msg._from in creator or msg._from in settings["admin"]:
            cond = cmd.split(" ")
            num = int(cond[1])
            gid = line.getGroupIdsJoined()
            group = line.getCompactGroup(gid[num-1])
            line.findAndAddContactsByMid(sender)
            line.inviteIntoGroup(gid[num-1],[sender])                
            line.sendMessage(msg.to,"Done invite @!")
    elif cmd.startswith('error'):
      if msg._from in creator or msg._from in settings["admin"]:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        cond = textt.split(' ')
        res = '\n • {key}Error'
        res += '\n • {key}Error Logs'
        res += '\n • {key}Error Reset'
        res += '\n • {key}Error Detail <errid>'
        if cmd == 'error':
            line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        elif cond[0].lower() == 'logs':
            try:
                filee = open('errorLog.txt', 'r')
            except FileNotFoundError:
                return line.sendMessage(to, 'Failed display error logs, error logs file not found')
            errors = [err.strip() for err in filee.readlines()]
            filee.close()
            if not errors: return line.sendMessage(to, 'Failed display error logs, empty error logs')
            res = '╔═══ ☞︎︎︎ Error Logs ]'
            res += '\n║✈︎ List :'
            parsed_len = len(errors)//200+1
            no = 0
            for point in range(parsed_len):
                for error in errors[point*200:(point+1)*200]:
                    if not error: continue
                    no += 1
                    res += '\n│ %i. %s' % (no, error)
                    if error == errors[-1]:
                        res += '\n╚═══ [ TEAM TERMUX™ ]'
                if res:
                    if res.startswith('\n'): res = res[1:]
                    line.sendMessage(to, res)
                res = ''
        elif cond[0].lower() == 'reset':
            filee = open('errorLog.txt', 'w')
            filee.write('')
            filee.close()
            shutil.rmtree('tmp/errors/', ignore_errors=True)
            os.system('mkdir tmp/errors')
            line.sendMessage(to, 'Success reset error logs')
        elif cond[0].lower() == 'detail':
            if len(cond) < 2:
                return line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
            errid = cond[1]
            if os.path.exists('tmp/errors/%s.txt' % errid):
                with open('tmp/errors/%s.txt' % errid, 'r') as f:
                    line.sendMessage(to, f.read())
            else:
                return line.sendMessage(to, 'Failed display details error, errorid not valid')
        else:
            line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
    elif txt.startswith('rname'):
      if msg._from in creator or msg._from in settings["admin"]:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        res = settings['setKey']['key'].title()
        if txt == 'rname':
            line.sendMessage(to, (res))       	
    elif txt.startswith('uprname'):
      if msg._from in creator or msg._from in settings["admin"]:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        res = settings['setKey']['key'].title()
        if txt == 'uprname':
            line.sendMessage(to, parsingRes(res))
        else:
            settings['setKey']['key'] = texttl
            line.sendMessage(to, 'Success change rname to (%s)' % textt)
    elif cmd.startswith('autojoin'):
      if msg._from in creator or msg._from in settings["admin"]:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        cond = textt.split(' ')
        if cmd == 'autojoin':
            line.sendMessage(to,(res).format_map(SafeDict(key=setKey.title())))
        elif texttl == 'on':
            if settings['autoJoin']['status']:
                line.sendMessage(to, 'Autojoin already active')
            else:
                settings['autoJoin']['status'] = True
                line.sendMessage(to, 'Success activated autojoin')
        elif texttl == 'off':
            if not settings['autoJoin']['status']:
                line.sendMessage(to, 'Autojoin already deactive')
            else:
                settings['autoJoin']['status'] = False
                line.sendMessage(to, 'Success deactivated autojoin')
        elif cond[0].lower() == 'reply':
            if len(cond) < 2:
                return line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
            if cond[1].lower() == 'on':
                if settings['autoJoin']['reply']:
                    line.sendMessage(to, 'Reply message autojoin already active')
                else:
                    settings['autoJoin']['reply'] = True
                    line.sendMessage(to, 'Success activate reply message autojoin')
            elif cond[1].lower() == 'off':
                if not settings['autoJoin']['reply']:
                    line.sendMessage(to, 'Reply message autojoin already deactive')
                else:
                    settings['autoJoin']['reply'] = False
                    line.sendMessage(to, 'Success deactivate reply message autojoin')
            else:
                line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        elif cond[0].lower() == 'ticket':
            if len(cond) < 2:
                return line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
            if cond[1].lower() == 'on':
                if settings['autoJoin']['ticket']:
                    line.sendMessage(to, 'Autojoin ticket already active')
                else:
                    settings['autoJoin']['ticket'] = True
                    line.sendMessage(to, 'Success activate autojoin ticket')
            elif cond[1].lower() == 'off':
                if not settings['autoJoin']['ticket']:
                    line.sendMessage(to, 'Autojoin ticket already deactive')
                else:
                    settings['autoJoin']['ticket'] = False
                    line.sendMessage(to, 'Success deactivate autojoin ticket')
            else:
                line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        else:
            settings['autoJoin']['message'] = textt
            line.sendMessage(to, 'Success change autojoin message to `%s`' % textt)
    elif cmd == "changepict":
      if msg._from in creator or msg._from in settings["admin"]:
        settings['changePictureProfile'] = True
        line.sendMessage(to, 'Please send the image to set in picture profile, type `Abort` if want cancel it.\nFYI: Downloading images will fail if too long upload the image'.format(key=setKey.title()))
    elif cmd == "changecover":
      if msg._from in creator or msg._from in settings["admin"]:
        settings['changeCoverProfile'] = True
        line.sendMessage(to, 'Please send the image to set in cover profile, type `Abort` if want cancel it.\nFYI: Downloading images will fail if too long upload the image'.format(key=setKey.title()))
    elif cmd == "changevp":
      if msg._from in creator or msg._from in settings["admin"]:
        settings["changevp"] = True
        line.sendReplyMessage(msg_id, to, "Kirim video nya")
    elif cmd.startswith("getmid "):
      if msg._from in creator or msg._from in settings["admin"]:
       if 'MENTION' in msg.contentMetadata.keys()!= None:
           names = re.findall(r'@(\w+)', text)
           mention = ast.literal_eval(msg.contentMetadata['MENTION'])
           mentionees = mention['MENTIONEES']
           lists = []
           for mention in mentionees:
               if mention["M"] not in lists:
                   lists.append(mention["M"])
           ret_ = ""
           for ls in lists:
               ret_ += "{}".format(str(ls))
           line.generateReplyMessage(msg.id)
           line.sendReplyMessage(msg.id, to, str(ret_))    
    elif cmd.startswith("bcs: "):
      if msg._from in creator or msg._from in settings["admin"]:
        bob = text.split(" ")
        hey = text.replace(bob[0] + " ", "")
        text = ""
        text += "{}".format(hey)
        groups = line.getGroupIdsJoined()
        for gr in groups:
            line.sendMessage(gr, text)
            time.sleep(0.2)
        line.sendMessage(to, 'wait a minute for the next broadcast')
        line.sendReplyMessage(msg.id, to, 'Success broadcast to all groups, sent to %i groups' % len(groups))
    elif cmd.startswith('friendlist'):
      if msg._from in creator or msg._from in settings["admin"]:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        cids = line.getAllContactIds()
        cids.sort()
        cnames = []
        ress = []
        res = '╭───[ Friend List ]'
        res += '\n├☬ List:'
        if cids:
            contacts = []
            no = 0
            if len(cids) > 200:
                parsed_len = len(cids)//200+1
                for point in range(parsed_len):
                    for cid in cids[point*200:(point+1)*200]:
                        try:
                            contact = line.getContact(cid)
                            contacts.append(contact)
                        except TalkException:
                            cids.remove(cid)
                            continue
                        no += 1
                        res += '\n│ %i. %s' % (no, contact.displayName)
                        cnames.append(contact.displayName)
                    if res:
                        if res.startswith('\n'): res = res[1:]
                        if point != parsed_len - 1:
                            ress.append(res)
                    if point != parsed_len - 1:
                        res = ''
            else:
                for cid in cids:
                    try:
                        contact = line.getContact(cid)
                        contacts.append(contact)
                    except TalkException:
                        cids.remove(cid)
                        continue
                    no += 1
                    res += '\n│ %i. %s' % (no, contact.displayName)
                    cnames.append(contact.displayName)
        else:
            res += '\n│ Nothing'
        res += '\n├☬ Usage : '
        res += '\n│ • FriendList'
        res += '\n│ • FriendList Info <num/name>'
        res += '\n│ • FriendList Add <mention>'
        res += '\n│ • FriendList Del <mention/num/name/all>'
        res += '\n╰───[ TEAM TERMUX™ ]'
        ress.append(res)
        if cmd == 'friendlist':
            for res in ress:
                line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
    elif cmd.startswith('grouplist'):
      if msg._from in creator or msg._from in settings["admin"]:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        gids = line.getGroupIdsJoined()
        gnames = []
        ress = []
        res = '𝐆𝐫𝐨𝐮𝐩𝐥𝐢𝐬𝐭'
        if gids:
            groups = line.getGroups(gids)
            no = 0
            if len(groups) > 200:
                parsed_len = len(groups)//200+1
                for point in range(parsed_len):
                    for group in groups[point*200:(point+1)*200]:
                        no += 1
                        res += '\n %i. %s [%i]' % (no, group.name, len(group.members))
                        gnames.append(group.name)
                    if res:
                        if res.startswith('\n'): res = res[1:]
                        if point != parsed_len - 1:
                            ress.append(res)
                    if point != parsed_len - 1:
                        res = ''
            else:
                for group in groups:
                    no += 1
                    res += '\n %i. %s [%i]' % (no, group.name, len(group.members))
                    gnames.append(group.name)
        else:
            res += '\n Nothing Group'
        res += '\n {key} GroupList'
        res += '\n {key}GroupList Leave: <Value>|<All>'
        res += '\n {key} Ginfo: <Value>'
        res += '\n {key} Mentionall: <Value>'
        res += '\n {key} Infomem: <Value>'
        res += '\n {key} Openqr: <Value>'
        res += '\n {key} Closeqr: <Value>'
        res += '\n {key}Inviteme <Value>'
        res += '\nTEAM TERMUX™'
        ress.append(res)
        if cmd == 'grouplist':
          if msg._from in creator or msg._from in settings["admin"]:	
            for res in ress:
                line.sendMessage(to,(res).format_map(SafeDict(key=setKey.title())))
        elif texttl.startswith('accept'):
            texts = textt[7:].split('')
            accepted = []
            if not gids:
                return line.sendMessage(to,'Failed accept group, nothing invitation group in list')
            for texxt in texts:
                num = None
                name = None
                try:
                    num = int(texxt)
                except ValueError:
                    name = texxt
                if num != None:
                    if num <= len(groups) and num > 0:
                        group = groups[num - 1]
                        if group.id in accepted:
                            line.sendMessage(to,'Already accept group %s' % group.name)
                            continue
                        line.acceptGroupInvitation(group.id)
                        accepted.append(group.id)
                        line.sendMessage(to,'Success accept group %s' % group.name)
                    else:
                        line.sendMessage(to,'Failed accept group number %i, number out of range' % num)
                elif name != None:
                    if name in gnames:
                        group = groups[gnames.index(name)]
                        if group.id in accepted:
                            line.sendMessage(to,'Already accept group %s' % group.name)
                            continue
                        line.acceptGroupInvitation(group.id)
                        accepted.append(group.id)
                        line.sendMessage(to,'Success accept group %s' % group.name)
                    elif name.lower() == 'all':
                        for gid in gids:
                            if gid in accepted:
                                continue
                            line.acceptGroupInvitation(gid)
                            accepted.append(gid)
                            time.sleep(0.8)
                        line.sendMessage(to,'Success accept all invitation group ♪')
                    else:
                        line.sendMessage(to,'Failed accept group with name `%s`, name not in list ♪' % name)
        elif texttl.startswith('leave:'):
          if msg._from in creator or msg._from in settings["admin"]:	
            texts = textt[6:].split(':')
            leaved = []
            if not gids:
                return line.sendMessage(to, 'Failed leave group, nothing group in list')
            for texxt in texts:
                num = None
                name = None
                try:
                    num = int(texxt)
                except ValueError:
                    name = texxt
                if num != None:
                    if num <= len(groups) and num > 0:
                        group = groups[num - 1]
                        if group.id in leaved:
                            line.sendMessage(to, 'Already leave group %s' % group.name)
                            continue
                        line.leaveGroup(group.id)
                        leaved.append(group.id)
                        if to not in leaved:
                            line.sendMessage(to, 'Success leave group %s' % group.name)
                    else:
                        line.sendMessage(to, 'Failed leave group number %i, number out of range' % num)
                elif name != None:
                    if name in gnames:
                        group = groups[gnames.index(name)]
                        if group.id in leaved:
                            line.sendMessage(to, 'Already leave group %s' % group.name)
                            continue
                        line.leaveGroup(group.id)
                        leaved.append(group.id)
                        if to not in leaved:
                            line.sendMessage(to, 'Success leave group %s' % group.name)
                    elif name.lower() == 'all':
                        for gid in gids:
                            if gid in leaved:
                                continue
                            line.leaveGroup(gid)
                            leaved.append(gid)
                            time.sleep(0.8)
                        if to not in leaved:
                            line.sendMessage(to, 'Success leave all group ')
                    else:
                        line.sendMessage(to, 'Failed leave group with name `%s`, name not in list ' % name)
        else:
            for res in ress:
                line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
    elif cmd == 'infomem':
      if msg._from in creator or msg._from in settings["admin"]:
        if msg.toType == 1:
            room = line.getRoom(to)
            members = room.contacts
        elif msg.toType == 2:
            group = line.getGroup(to)
            members = group.members
        else:
            return line.sendMessage(to, 'Failed display member list, use this command only on room or group chat')
        if not members:
            return line.sendMessage(to, 'Failed display member list, no one contact')
        res = '𝗜𝗡𝗙𝗢 𝗠𝗘𝗠𝗕𝗘𝗥'
        parsed_len = len(members)//200+1
        no = 0
        for point in range(parsed_len):
            for member in members[point*200:(point+1)*200]:
                no += 1
                res += '\n%i. %s' % (no, member.displayName)
                if member == members[-1]:
                     res += '\n              '
            if res:
                if res.startswith('\n'): res = res[1:]
                line.sendMessage(to, res)
            res = ''           
    elif cmd.startswith('infomem:'):
      if msg._from in creator or msg._from in settings["admin"]:
                                    separate = msg.text.split(":")
                                    number = msg.text.replace(separate[0] + ":","")
                                    groups = line.getGroupIdsJoined()
                                    ret_ = ""
                                    try:
                                        group = groups[int(number)-1]
                                        G = line.getGroup(group)
                                        no = 0
                                        ret_ = ""
                                        for mem in G.members:
                                           no += 1
                                           ret_ += "\n " " "+ str(no) + ". " + mem.displayName
                                        line.sendReplyMessage(msg.id, to," Group Name : [ " + str(G.name) + " ]\n\n   [ List Member ]\n" + ret_ + "\n\nTotal %i Members" % len(G.members))
                                    except:
                                           pass                        
#================Feature================
    elif cmd.startswith('changename:'):
      if msg._from in creator or msg._from in settings["admin"]:	
        separate = text.split(':')
        name = text.replace(separate[0] + ':','')
        profile = line.getProfile()
        profile.displayName = str(name)
        line.updateProfile(profile)
        line.sendMessage(to, 'Success change display name, changed to `%s`' % name)
    elif cmd.startswith('changebio'):
      if msg._from in creator or msg._from in settings["admin"]:
        if len(bio) <= 500:
            profile.statusMessage = bio
            line.updateProfile(profile)
            line.sendMessage(to, 'Success change status message, changed to `%s`' % bio)
        else:
            line.sendMessage(to, 'Failed change status message, the length of the bio cannot be more than 500')
    elif cmd == "changepict":
      if msg._from in creator or msg._from in settings["admin"]:
        settings['changePictureProfile'] = True
        line.sendMessage(to, 'Please send the image to set in picture profile, type `Abort` if want cancel it.\nFYI: Downloading images will fail if too long upload the image'.format(key=setKey.title()))
    elif cmd == "changevp":
      if msg._from in creator or msg._from in settings["admin"]:
        settings["changevp"] = True
        line.sendReplyMessage(msg_id, to, "Kirim video nya")
    elif cmd.startswith("getmid "):
      if msg._from in creator or msg._from in settings["admin"]:
       if 'MENTION' in msg.contentMetadata.keys()!= None:
           names = re.findall(r'@(\w+)', text)
           mention = ast.literal_eval(msg.contentMetadata['MENTION'])
           mentionees = mention['MENTIONEES']
           lists = []
           for mention in mentionees:
               if mention["M"] not in lists:
                   lists.append(mention["M"])
           ret_ = ""
           for ls in lists:
               ret_ += "{}".format(str(ls))
           line.generateReplyMessage(msg.id)
           line.sendReplyMessage(msg.id, to, str(ret_))    
    elif cmd.startswith("spamtag "):
      if msg._from in creator or msg._from in settings["admin"]:
            dan = text.split(" ")
            num = int(dan[1])
            text = " Spamtag \nBerhasil {} Spamtag".format(str(dan[1]))
            if 'MENTION' in msg.contentMetadata.keys()!= None:
                names = re.findall(r'@(\w+)', text)
                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                mentionees = mention['MENTIONEES']
                lists = []
                for mention in mentionees:
                    if mention["M"] not in lists:
                        lists.append(mention["M"])
                for ls in lists:
                    for var in range(0,num):
                        sendMention(to, "@!", [ls])
                line.sendMessage(to, text)
                line.sendReplyMessage(msg.id, to, str(text.replace(spam[0] + " " + spam[1] + " ","")))
def executeOp(op):
    try:
        print ('++ Operation : ( %i ) %s' % (op.type, OpType._VALUES_TO_NAMES[op.type].replace('_', ' ')))
        if op.type == 5:
            if settings['autoAdd']['status']:
                line.findAndAddContactsByMid(op.param1)
            if settings['autoAdd']['reply']:
                if '@!' not in settings['autoAdd']['message']:
                    line.sendMessage(op.param1, settings['autoAdd']['message'])
                else:
                    line.sendMentionV2(op.param1, settings['autoAdd']['message'], [op.param1])
        if op.type == 13 or op.type == 124:
            if settings['autoJoin']['status'] and myMid in op.param3:
                line.acceptGroupInvitation(op.param1)
                if settings['autoJoin']['reply']:
                    if '@!' not in settings['autoJoin']['message']:
                        line.sendMessage(op.param1, settings['autoJoin']['message'])
                    else:
                        line.sendMentionV2(op.param1, settings['autoJoin']['message'], [op.param2])
        if op.type == 19 or op.type == 133:
          if op.param3 in myMid:
                ban["blacklist"].append(op.param2)
                group = "u6459106c8251205f79c2f037cd99b6a4" #mid gc dapat di lihat di groupinfo
                nameGroup = line.getGroup(op.param1).name
                jam = pytz.timezone("Asia/Jakarta")
                jamSek = datetime.now(tz=jam)
                jamm = datetime.strftime(jamSek, '%d-%m-%Y')
                jammm = datetime.strftime(jamSek,'%H:%M:%S')
                contact = line.getContact(myMid)
                kiker = line.getContact(op.param2)
                res = " 𝐍𝐨𝐭𝐢𝐟𝐢𝐤𝐚𝐬𝐢 𝐊𝐢𝐜𝐤"
                res += "\n In Group: {}".format(nameGroup)
                res += "\n Date: {}".format(jamm)
                res += "\n Time: {}".format(jammm)
                res += "\n Victim : {}".format(contact.displayName)
                res += "\n Kicker: {}".format(kiker.displayName)
                #res += "\n --- TEAM TERMUX™ ---"
                line.sendMessage("u6459106c8251205f79c2f037cd99b6a4",res)
                data = {
                                           "type": "text",
                                           "text": "{}".format(str(res)),
                                           "sentBy": {
                                           "label": "TEAM TERMUX™".format(line.getContact(myMid).displayName),
                                           "iconUrl": "https://i.ibb.co/QNFxN8N/1652366614290.jpg".format(line.getContact(myMid).pictureStatus),
                                           "linkUrl": "line://nv/profilePopup/mid=u6459106c8251205f79c2f037cd99b6a4",
                                         }
                                     }
                sendTemplate(group, data)
                line.sendContact(group, op.param2)	
                
        if op.type == 55:
            if op.param1 in read["readPoint"]:
                if op.param2 not in read["readMember"][op.param1]:
                    read["readMember"][op.param1].append(op.param2)

        if op.type == 55:
            if cctv['cyduk'][op.param1]==True:
                if op.param1 in cctv['point']:
                    Name = line.getContact(op.param2).displayName
                    if Name in cctv['sidermem'][op.param1]:
                        pass
                    else:
                        cctv['sidermem'][op.param1] += "\n " + Name
                        teambotmaxZ={'previewUrl': "http://dl.profile.line-cdn.net/"+line.getContact(op.param2).picturePath, 'i-installUrl': 'http://itunes.apple.com/app/linemusic/id966142320', 'type': 'mt', 'subText': 'creator : 𝑨𝑹𝑰𝑭', 'a-installUrl': 'market://details?id=jp.linecorp.linemusic.android', 'a-packageName': 'jp.linecorp.linemusic.android', 'countryCode': 'JP', 'a-linkUri': 'linemusic://open?target=track&item=mb00000000016197ea&subitem=mt000000000d69e2db&cc=JP&from=lc&v=1', 'i-linkUri': 'linemusic://open?target=track&item=mb00000000016197ea&subitem=mt000000000d69e2db&cc=JP&from=lc&v=1', 'text': line.getContact(op.param2).displayName, 'id': 'mt000000000d69e2db', 'linkUri': 'https://music.me.me/launch?target=track&item=mb00000000016197ea&subitem=mt000000000d69e2db&cc=JP&from=lc&v=1','MSG_SENDER_ICON': "https://os.line.naver.jp/os/p/"+op.param2,'MSG_SENDER_NAME':  line.getContact(op.param2).displayName,}
                        line.sendMessage(op.param1, line.getContact(op.param2).displayName, teambotmaxZ, 19)
        if op.type == 25:
            print ("++ Operation : ( 25 ) SEND MESSAGE")
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0:
                if sender != line.profile.mid:
                    to = sender
                else:
                    to = receiver
            else:
                to = receiver
            if msg.contentType == 0:
                if text is None:
                    return
                if text.lower() == 'wait....':
                    line.removeAllMessages(op.param2)
                    line.sendMessage(to, "Success Remove Allchat")
        if op.type == 26:
            msg      = op.message
            text     = str(msg.text)
            msg_id   = msg.id
            receiver = msg.to
            sender   = msg._from
            to       = sender if not msg.toType and sender != myMid else receiver
            txt      = text.lower()
            cmd      = command(text)
            setKey   = settings['setKey']['key'] if settings['setKey']['status'] else ''
            if text in tmp_text:
                return tmp_text.remove(text)
            if msg.contentType == 0:
                if '/ti/g/' in text and settings['autoJoin']['ticket']:
                    regex = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                    links = regex.findall(text)
                    tickets = []
                    gids = line.getGroupIdsJoined()
                    for link in links:
                        if link not in tickets:
                            tickets.append(link)
                    for ticket in tickets:
                        try:
                            group = line.findGroupByTicket(ticket)
                        except:
                            continue
                        if group.id in gids:
                            line.sendMessage(to, 'I\'m already on group ' + group.name)
                            continue
                        line.acceptGroupInvitationByTicket(group.id, ticket)
                        if settings['autoJoin']['reply']:
                            if '@!' not in settings['autoJoin']['message']:
                                line.sendMessage(to, settings['autoJoin']['message'])
                            else:
                                line.sendMentionV2(to, settings['autoJoin']['message'], [sender])
                        line.sendMessage(to, 'Success join to group ' + group.name)
                try:
                    executeCmd(msg, text, txt, cmd, msg_id, receiver, sender, to, setKey)
                except TalkException as talk_error:
                    logError(talk_error)
                    if talk_error.code in [7, 8, 20]:
                        sys.exit(1)
                    line.sendMessage(to, 'Execute command error, ' + str(talk_error))
                    time.sleep(3)
                except Exception as error:
                    logError(error)
                    line.sendMessage(to, 'Execute command error, ' + str(error))
                    time.sleep(3)
            elif msg.contentType == 1: # Content type is image
                if settings['changePictureProfile']:
                    path = line.downloadObjectMsg(msg_id, saveAs='tmp/picture.jpg')
                    line.updateProfilePicture(path)
                    line.sendMessage(to, 'Success change picture profile')
                    settings['changePictureProfile'] = False
                elif settings['changeCoverProfile']:
                    path = line.downloadObjectMsg(msg_id, saveAs='tmp/cover.jpg')
                    line.updateProfileCover(path)
                    line.sendMessage(to, 'Success change cover profile')
                    settings['changeCoverProfile'] = False
                elif to in settings['changeGroupPicture'] and msg.toType == 2:
                    path = line.downloadObjectMsg(msg_id, saveAs='tmp/grouppicture.jpg')
                    line.updateGroupPicture(to, path)
                    line.sendMessage(to, 'Success change group picture')
                    settings['changeGroupPicture'].remove(to)
            elif msg.contentType == 2: #content type video
                if settings["changevp"] == True:
                    contact = line.getProfile()
                    pict = "https://obs.line-scdn.net/".format(contact.pictureStatus)
                    path = line.downloadFileURL(pict)
                    path1 = line.downloadObjectMsg(msg_id)
                    settings["changevp"] = False
                    changevideopp(path, path1)
                    line.sendMessage(to, "Success change Video Profile")
            elif msg.contentType == 13: # Content type is contact
                if settings['checkContact']:
                    mid = msg.contentMetadata['mid']
                    try:
                        contact = line.getContact(mid)
                    except:
                        return line.sendMessage(to, 'Failed get details contact with mid ' + mid)
                    res = '' + mid
                    line.sendMessage(to, parsingRes(res))         
        elif op.type == 26:
            msg      = op.message
            text     = str(msg.text)
            msg_id   = msg.id
            receiver = msg.to
            sender   = msg._from
            to       = sender if not msg.toType and sender != myMid else receiver
            txt      = text.lower()
            if settings['autoRead']:
                line.sendChatChecked(to, msg_id)
            if msg.contentType == 0:
                if msg.toType != 0 and msg.toType == 2:
                    if 'MENTION' in msg.contentMetadata.keys()!= None:
                        names = re.findall(r'@(\w+)', text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        for mention in mentionees:
                            if myMid in mention["M"]:
                                if line.getProfile().mid in mention["M"]:
                                    if to not in tagme['ROM']:
                                        tagme['ROM'][to] = {}
                                    if sender not in tagme['ROM'][to]:
                                        tagme['ROM'][to][sender] = {}
                                    if 'msg.id' not in tagme['ROM'][to][sender]:
                                        tagme['ROM'][to][sender]['msg.id'] = []
                                    if 'waktu' not in tagme['ROM'][to][sender]:
                                        tagme['ROM'][to][sender]['waktu'] = []
                                    tagme['ROM'][to][sender]['msg.id'].append(msg.id)
                                    tagme['ROM'][to][sender]['waktu'].append(msg.createdTime)
            if msg.contentType == 0: # Content type is text
                if '/ti/g/' in text and settings['autoJoin']['ticket']:
                    regex = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                    links = regex.findall(text)
                    tickets = []
                    gids = line.getGroupIdsJoined()
                    for link in links:
                        if link not in tickets:
                            tickets.append(link)
                    for ticket in tickets:
                        try:
                            group = line.findGroupByTicket(ticket)
                        except:
                            continue
                        if group.id in gids:
                            line.sendMessage(to, 'I\'m already on group ' + group.name)
                            continue
                        line.acceptGroupInvitationByTicket(group.id, ticket)
                        if settings['autoJoin']['reply']:
                            if '@!' not in settings['autoJoin']['message']:
                                line.sendMessage(to, settings['autoJoin']['message'])
                            else:
                                line.sendMentionV2(to, settings['autoJoin']['message'], [sender])
                        line.sendMessage(to, 'Success join to group ' + group.name)
                if settings['mimic']['status']:
                    if sender in settings['mimic']['target'] and settings['mimic']['target'][sender]:
                        try:
                            line.sendMessage(to, text, msg.contentMetadata)
                            tmp_text.append(text)
                        except:
                            pass
    except TalkException as talk_error:
        logError(talk_error)
        if talk_error.code in [7, 8, 20]:
            sys.exit(1)
    except KeyboardInterrupt:
        sys.exit('##---- KEYBOARD INTERRUPT -----##')
    except Exception as error:
        logError(error)
def runningProgram():
    if settings['restartPoint'] is not None:
        try:
            line.sendMessage(settings['restartPoint'], 'RESTART BOTS SUCCESS ♪')
        except TalkException:
            pass
        settings['restartPoint'] = None
    while True:
        try:
            ops = oepoll.singleTrace(count=50)
        except TalkException as talk_error:
            logError(talk_error)
            if talk_error.code in [7, 8, 20]:
                sys.exit(1)
            continue
        except KeyboardInterrupt:
            sys.exit('##---- KEYBOARD INTERRUPT -----##')
        except Exception as error:
            logError(error)
            continue
        if ops:
            for op in ops:
                executeOp(op)
                oepoll.setRevision(op.revision)
if __name__ == '__main__':
    print ('##---- RUNNING PROGRAM -----##')
    runningProgram()
